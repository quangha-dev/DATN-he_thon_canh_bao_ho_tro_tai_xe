# Handoff: SafeFleet — Web quản lý (Command Suite)

## Overview
Giao diện web cho quản trị viên / điều phối viên của hệ thống cảnh báo & hỗ trợ tài xế SafeFleet. Bao gồm màn hình đăng nhập và 15 màn hình trong ứng dụng: trung tâm điều hành, bản đồ realtime, quản lý tài xế / tài khoản / phương tiện, điều phối chuyến, chuyến đi & chứng từ, duyệt phiếu lệch biển số, cảnh báo AI, SOS/sự cố, điểm ngập, thiết bị, bảo trì, báo cáo, cấu hình, hồ sơ cá nhân. Có chế độ nền sáng / nền tối.

## About the Design Files
Các file trong gói này là **tài liệu thiết kế tham chiếu viết bằng HTML** — bản mẫu thể hiện hình thức và hành vi mong muốn, **không phải mã nguồn production để copy trực tiếp**.

Việc cần làm: **dựng lại các thiết kế này trong codebase thật** (`web_quan_ly/frontend` — Next.js App Router + React + Tailwind v4 + TypeScript, maplibre-gl cho bản đồ), dùng đúng component/pattern đã có ở đó. Dữ liệu trong bản mẫu là dữ liệu mẫu; hãy thay bằng API thật (REST + WebSocket).

Bản mẫu dùng inline style vì môi trường prototype yêu cầu như vậy. Trong codebase thật hãy chuyển sang Tailwind class / CSS variable theo `app/globals.css` và `DESIGN_SYSTEM.md` hiện có.

## Fidelity
**High-fidelity.** Màu, typography, spacing, bo góc, bóng, animation đều là giá trị cuối. Hãy dựng lại đúng pixel bằng thư viện sẵn có của codebase. Bản đồ trong prototype là bản đồ giả (grid + đường kẻ + ghim tuyệt đối) — trong codebase hãy thay bằng maplibre-gl với marker/layer thật, giữ nguyên style ghim, panel và tương tác.

---

## Design Tokens

### Màu
| Vai trò | Sáng | Tối (`[data-sf-theme="dark"]`) |
|---|---|---|
| Nền trang `--sf-bg` | `#f2f6f5` | `#0b1416` |
| Nền thẻ `--sf-card` | `#ffffff` | `#12201f` |
| Nền header `--sf-header` | `rgba(242,246,245,.82)` | `rgba(11,20,22,.8)` |
| Mực chính `--sf-text` / `--sf-ink` | `#0c1720` | `#e8f2f0` |
| Mực phụ `--sf-text2` | `#3d4f5c` | `#c2d3d1` |
| Mờ `--sf-muted` | `#5f7482` | `#94a8a7` |
| Mờ hơn `--sf-muted2` | `#8496a0` | `#7e9291` |
| Nền nhạt `--sf-subtle` | `#f4f7f7` | `#182a29` |
| Nền nhạt 2 `--sf-subtle2` | `#fbfcfd` | `#152625` |
| Nền nhạt 3 `--sf-subtle3` | `#f0f4f5` | `#1c2f2d` |
| Đường kẻ `--sf-line` | `rgba(16,28,37,.05)` | `rgba(190,230,225,.10)` |
| Đường kẻ 2 `--sf-line2` | `#e4ebea` | `rgba(190,230,225,.16)` |
| Accent `--sf-accent` | `#076a61` | `#5fd9c1` |
| Chip accent `--sf-chip` | `#e9faf5` | `#14322e` |
| Rãnh switch `--sf-track` | `#dbe3e4` | `#2b3d3c` |
| Hover `--sf-hover` | `rgba(16,28,37,.035)` | `rgba(190,230,225,.07)` |
| Pill nav đang chọn `--sf-pill` | `linear-gradient(100deg,#e8faf5,#f1fbf8)` | `linear-gradient(100deg,#123330,#16413b)` |
| Viền pill `--sf-pill-line` | `rgba(8,127,115,.10)` | `rgba(95,217,193,.22)` |

Màu thương hiệu & trạng thái (không đổi theo theme):

- Teal: `#34d3b5` (sáng), `#0b8c7f` (chính), `#087f73`, `#076a61`, `#075c56`, `#05403e`, `#0d7a70`
- Gradient nút chính: `linear-gradient(140deg,#0b8c7f,#076a61)`
- Gradient hero: `radial-gradient(115% 130% at 8% 0%, #0d7a70 0%, #075c56 55%, #05403e 100%)`
- Gradient logo: `linear-gradient(150deg,#34d3b5,#087f73)`, mực logo `#04211f`
- Thành công: nền `#e7f8f1`, mực `#0a7a58`, dot `#10b981`
- Cảnh báo: nền `#fef4e2` / `#fff8eb`, mực `#a85b07` / `#d17c05`, dot `#f59e0b`, sáng `#ffc74d`
- Nguy hiểm: nền `#fdeced`, mực `#c8393e`, dot `#e5484d`, sáng `#ff9ea1`
- Thông tin / ngập: nền `#eaf1fe`, mực `#2563c9`, dot `#3b82f6`, đậm `#1b4faa`, chữ `#274b86`
- Trung tính: nền `#f0f4f5`, mực `#5f7482`, dot `#8496a0`
- Mực trên nền tối (hero): `#f4fbfa`, `#e7f7f4`, `#d9efec`, `#a7ecdc`, `#7fe3cd`, phụ `rgba(206,232,229,.6–.78)`, viền `rgba(180,230,222,.16–.28)`, nền tile `rgba(255,255,255,.08–.10)`

### Typography
- Sans: **Plus Jakarta Sans** 400/500/600/700 (Google Fonts)
- Mono: **JetBrains Mono** 400/500 — dùng cho biển số, mã chuyến, số liệu, thời gian, toạ độ
- Icon: **Material Symbols Rounded**, `opsz 24, wght 300, FILL 0, GRAD 0`, class `.sym`
- Thang chữ: 9.5 / 10.5 / 11 / 11.5 / 12 / 12.5 / 13 / 13.5 / 14.5 / 15 / 15.5 / 16 / 17 / 19 / 20 / 21 / 24 / 27 / 29 / 30 / 46 px
- `letter-spacing`: tiêu đề `-.01em` → `-.02em`; nhãn uppercase `.08em` → `.13em`
- Tiêu đề thẻ 15.5px/700; nhãn phụ 12.5px; nhãn uppercase 10.5–11.5px; số liệu mono 17–30px
- `text-wrap: pretty` cho đoạn văn dài

### Spacing
Gap/padding dùng thang: 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 34, 36, 40 px.
- Padding main: `26px 30px 40px`; header cao `74px`, padding ngang `30px`
- Thanh bên: rộng `268px` (mở) / `84px` (thu gọn), padding `22px 16px 16px`
- Khoảng cách giữa thẻ trong lưới: `20px`; giữa thẻ thống kê: `14px`

### Bo góc
`8, 9, 10, 11, 12, 14, 15, 16, 18, 20, 22, 24, 26, 28, 34, 36, 38, 40, 44, 999px`
- Thẻ lớn: `28px` · Thẻ nhỏ / tile: `20px`, `18px`, `16px` · Ô nhập: `15–16px` · Nút pill: `999px` · Icon ô vuông: `11–16px`

### Bóng
- Thẻ: `0 2px 4px rgba(20,40,55,.03), 0 20px 44px -22px rgba(20,40,55,.16)`
- Thẻ thống kê: `0 2px 4px rgba(20,40,55,.03), 0 16px 34px -20px rgba(20,40,55,.18)`
- Hero tối: `0 26px 52px -22px rgba(8,64,62,.55)`
- Nút chính: `0 16px 32px -14px rgba(8,127,115,.7)` (hover `0 22px 40px -14px rgba(8,127,115,.78)`)
- Panel kính trên bản đồ: `0 24px 52px -20px rgba(20,40,55,.5)`, `backdrop-filter: blur(12–18px)`, viền `1px solid rgba(255,255,255,.8)`
- Toast: `0 24px 48px -18px rgba(8,20,28,.6)`

### Animation
| Tên | Dùng cho | Thời lượng & easing |
|---|---|---|
| `sfRise` | Đổi trang (`<main key={screen}>`), dropdown | `.56s cubic-bezier(.22,1,.36,1)`; opacity 0→1, translateY 16px→0, scale .985→1, blur 6px→0 |
| `sfFade` | Đăng nhập, wordmark | `.4–.5s ease` |
| `sfSlideLeft` | Hàng bảng, panel phải, thẻ việc cần xử lý | `.5s cubic-bezier(.22,1,.36,1)`, translateX 26px→0, stagger 55–70ms |
| `sfPop` | Thẻ thống kê, toast, thẻ chi tiết | `.4–.62s cubic-bezier(.34,1.4,.64,1)`, scale .9→1.012→1 |
| `sfPulseRing` | Ghim SOS | `2.2s ease-out infinite`, box-shadow lan 0→16px |
| `sfDot` | Dot trạng thái sống | `1.4–1.8s ease-in-out infinite` |
| `sfDrift` | Ghim xe di chuyển nhẹ | `12–16s ease-in-out infinite` |
| `sfBreathe` | Vòng lan điểm ngập, quầng sáng hero | `4.5–11s ease-in-out infinite`, scale 1→1.08 |
| `sfBar` | Cột biểu đồ | `.7s cubic-bezier(.22,1,.36,1)`, scaleY .18→1, `transform-origin: bottom`, stagger 40–50ms |
| Con trượt nav | Pill + vạch bên | `top .46s cubic-bezier(.34,1.32,.64,1)` |
| Chiều rộng thanh bên | Thu gọn / mở | `width .42s cubic-bezier(.22,1,.36,1)` |
| Ghim được chọn | Phóng to | `.34s cubic-bezier(.34,1.4,.64,1)` |
| Nút hover nâng | `transform: translateY(-2px)` | `.28s cubic-bezier(.34,1.4,.64,1)` |

Tôn trọng `@media (prefers-reduced-motion: reduce)` — mọi animation/transition rút về `.001ms`.

---

## Screens / Views

### 0. Đăng nhập
- **Layout**: `grid-template-columns: 1.05fr .95fr`, cao `100vh`.
  - Cột trái: panel gradient teal đậm, `border-radius: 0 44px 44px 0`, padding `64px 72px`, `space-between` theo trục dọc. Hai quầng sáng radial (`520px` phải-trên teal, `360px` trái-dưới amber) chạy `sfBreathe`. Nội dung: logo + wordmark; nhãn "TRUNG TÂM ĐIỀU HÀNH" 13px `#7fe3cd`; headline 46px/1.1/700 `#f4fbfa`; đoạn mô tả 15px/1.7; hai chip kính ("18 xe trực tuyến" có dot nhấp nháy, "AI giám sát liên tục"); chân trang "© 2026 SafeFleet" + hotline.
  - Cột phải: form rộng tối đa `412px`, `sfPop`. Nhãn "ĐĂNG NHẬP" + link "Quên mật khẩu?"; tiêu đề 30px/700; hai ô nhập (icon + input, bo `16px`, viền `#e4ebea`), ô mật khẩu có nút hiện/ẩn; nút chính đầy chiều rộng padding `16px` bo `18px`; dòng ghi chú bảo mật phiên 8 giờ.
- **Hành vi**: nút đăng nhập → vào ứng dụng (không xác thực trong prototype). Trong codebase: gọi API, xử lý lỗi, loading.

### 1. Khung ứng dụng (áp cho mọi màn hình sau đăng nhập)
- **Thanh bên** (`width` 268/84px, nền `--sf-card`, viền phải `--sf-line`):
  - **Logo là nút bấm** → thu gọn / mở thanh bên (hover `scale(1.06)`). Không có mục "Thu gọn" riêng.
  - `<nav>` cuộn dọc, chứa **pill nền** và **vạch 3px** định vị tuyệt đối theo nút đang chọn. Vị trí **đo bằng `getBoundingClientRect` + `scrollTop`** của nút active (không tính bằng công thức) — cập nhật ở `componentDidUpdate`, khi `nav` scroll, và 460ms sau khi thu/mở thanh bên.
  - 7 nhóm mục, nhãn nhóm 10.5px uppercase (ẩn khi thu gọn): Điều hành (Trung tâm điều hành, Bản đồ realtime) · Quản lý (Tài xế, Tài khoản, Phương tiện) · Vận hành (Điều phối chuyến, Chuyến đi & chứng từ, Duyệt phiếu lệch biển `badge 4` amber) · An toàn (Cảnh báo AI `badge 9` amber, SOS/Sự cố `badge 2` đỏ, Điểm ngập & rủi ro) · Đội xe (Thiết bị, Bảo trì) · Phân tích (Báo cáo) · Hệ thống (Cấu hình, Hồ sơ cá nhân).
  - Mỗi mục cao `44px`, gap `12px`, bo `16px`, chữ 13.5px/500; icon 21px; active dùng `--sf-accent`.
  - Chân thanh bên: nút **Nền tối / Nền sáng** (icon `dark_mode`/`light_mode`) và **Đăng xuất** (hover nền `#fdeced`, chữ `#c8393e`).
- **Header** (cao 74px, `backdrop-filter: blur(14px)`): khối tiêu đề (`flex:1 1 auto; min-width:0`, nhãn nhóm uppercase 11px + tên trang 19px/700, ellipsis) · ô tìm nhanh (`flex:0 1 auto`, hiện chữ + phím tắt `Ctrl K`; **dưới 1180px rút thành nút chỉ icon**) · nút thông báo 42px có dot đỏ · nút hồ sơ (avatar chữ đầu 34px + tên + vai trò), `flex:none`.
- **Main**: `overflow-y:auto`, `key={screen}` để chạy lại `sfRise` mỗi lần đổi trang.
- **Toast**: cố định `bottom:28px`, giữa ngang, nền `#0c1720`, bo `999px`, tự ẩn sau **2400ms**.
- **Responsive**: cờ `compact` bật khi `window.innerWidth < 1180` (nghe `resize`). Khi compact: mọi lưới trang về 1 cột, lưới thống kê 2 cột, ô tìm nhanh còn icon.

### 2. Trung tâm điều hành
Hai hàng, gap 20px.
- **Hàng 1** `grid-template-columns: minmax(0,1.15fr) minmax(0,.85fr)`, `align-items: stretch`:
  - **Thẻ hero** gradient teal, bo `28px`, padding `28px 30px`, `display:flex; flex-direction:column`; quầng `340px` chạy `sfBreathe`. Nội dung: nhãn "ĐỘI XE HÔM NAY" + ngày giờ; nút "Bản đồ realtime" → trang bản đồ; **5 tile** (`repeat(5,minmax(0,1fr))`, `sfPop` stagger 60ms): 12 Đang vận hành · 9 Có cảnh báo (`#ffc74d`) · 3 Mất GPS · 2 SOS mở (`#ff9ea1`) · 4 Điểm ngập; **biểu đồ 12 cột** (cao 56px, hai cột nhấn `rgba(127,227,205,.55/.85)`, `sfBar` stagger 50ms) + caption; `flex:1` đệm cuối để thẻ cao bằng cột phải.
  - **Thẻ "Việc cần xử lý ngay"** (4 việc theo ưu tiên): 3 thẻ con `sfSlideLeft` stagger 70ms — SOS nghiêm trọng (nền `#fdeced`, dot nhấp nháy, nút Tiếp nhận đỏ / Xem chi tiết / Gọi), Ngủ gật cao (nút Tiếp nhận teal), Điểm ngập trung bình (Xác minh / Gửi cảnh báo). Nhóm nút `flex-wrap: wrap`, chữ nút `white-space: nowrap`.
- **Hàng 2** hai cột bằng nhau (`gridHalf`), `align-items:start`: **Chuyến đang chạy** (3 dòng: mã + biển, %, thanh tiến độ gradient teal hoặc amber khi rủi ro, dòng tuyến + tài xế) và **Tài xế rủi ro cao** (3 dòng: vòng `conic-gradient` hiển thị điểm an toàn 55/62/68 + tên + số cảnh báo).
- **Không có thẻ bản đồ ở trang này** (đã tách sang trang bản đồ riêng).

### 3. Bản đồ realtime
Một khung duy nhất cao `calc(100vh - 140px)`, min `540px`, bo `28px`, `overflow:hidden`, không có nội dung nào phía dưới.
- **Lớp bản đồ** (`position:absolute; inset:0`) chịu `transform: translate(panX,panY) scale(zoom)`, `transform-origin:center`, transition `.32s cubic-bezier(.22,1,.36,1)` (tắt khi đang kéo). Nền: lưới 58px, 4 dải đường trắng xoay nhẹ, 2 vùng khu vực.
- **Điểm ngập** (4): vòng lan `radial-gradient` đường kính 80–118px chạy `sfBreathe` (`pointer-events:none`) + ghim vuông bo `14px` (`#3b82f6` ngập vừa, `#2563c9` ngập nặng, `#1b4faa` đường bị chặn, icon `water`/`block`), `z-index:2`.
- **Ghim xe** (10): vuông bo `16px`, màu theo trạng thái (`#0b8c7f` đang chạy, `#f59e0b` cảnh báo, `#e5484d` SOS, `#8496a0` mất GPS), icon theo loại xe; `z-index:3`. Ghim được chọn: `44–46px` + vòng trắng `0 0 0 5px rgba(255,255,255,.9)`.
- **Hàng điều khiển trên** (`left/right 20px; top 20px`, một hàng flex): **thanh tìm kiếm** (`flex:1 1 auto; max-width:440px`, cao 44px, placeholder "Tìm xe, tài xế hoặc điểm ngập…", nút xoá khi có chữ; dropdown kết quả neo `top:52px`, tối đa 6 kết quả, mỗi dòng icon + tên + phụ đề, có trạng thái "không tìm thấy") · **nút "Danh sách xe"** (bật/tắt panel, khi bật nền `#0b8c7f` chữ trắng) · **cụm zoom** (`+`, `−`, `filter_center_focus`, mỗi nút 44px, xếp dọc, `margin-left:auto`).
- **Panel danh sách xe** (khi bật): trái, `top:80px; bottom:80px`, rộng `288px` (co còn `244px` khi panel báo cáo đang mở), header "Xe trên bản đồ · 10 xe" + nút đóng, danh sách cuộn: dot trạng thái, biển số mono, tốc độ, tên tài xế, chip trạng thái; dòng đang chọn nền `#f1fbf8` + viền trong teal.
- **Panel báo cáo chi tiết** (khi bấm ghim, `sfSlideLeft`): phải, `top:80px; bottom:20px`, rộng `min(340px, 100% - 40px)`, 3 phần — header (nhãn loại, tiêu đề, phụ đề, nút đóng, chip trạng thái có dot), thân cuộn, chân 2 nút.
  - Xe: thẻ chuyến (mã, tuyến, %, thanh tiến độ, ETA đỏ khi trễ) · 2 tile (Tốc độ hiện tại, Lái liên tục — đỏ khi ≥ 3h30) · danh sách Tài xế / Điện thoại / Loại xe / Tín hiệu GPS (đỏ khi mất) / Thiết bị · dải tình trạng cảnh báo (đỏ khi có cảnh báo, xám khi mất GPS, xanh khi sạch) · nút "Gọi tài xế" + "Xem chuyến".
  - Điểm ngập: 2 tile (Mức ngập, Cập nhật) · dải mô tả nguồn báo · nút "Cảnh báo xe gần" + "Mở trang điểm ngập".
- **Chú thích màu**: pill kính góc dưới-trái, 5 mục (Đang chạy, Cảnh báo, SOS, Mất GPS, Điểm ngập).
- **Tương tác**: kéo chuột để di chuyển (giới hạn `±(zoom-1)*420px`), cuộn để zoom `±0.2`, nút `±0.4`, giới hạn `1–3`, nút reset về `zoom 1, pan 0`. Con trỏ `grab` / `grabbing`. `mousedown` bỏ qua khi target nằm trong `button, input`.
- **Panel kính phải ghim mực tối** (`color:#0c1720` ở gốc panel) vì nền panel luôn trắng ở cả hai theme.

### 4–11. Các trang dạng bảng (Tài xế, Tài khoản, Phương tiện, Chuyến đi & chứng từ, Duyệt phiếu lệch biển, Cảnh báo AI, SOS/Sự cố, Thiết bị, Bảo trì)
Cùng một khuôn, khác dữ liệu/cột:
- **4 thẻ thống kê** (`repeat(4,minmax(0,1fr))`, gap 14px, bo `24px`, `sfPop` stagger 70ms). Thẻ đầu thường là thẻ tô đặc gradient teal; các thẻ sau nền `--sf-card` với icon vuông 32px màu theo tone (ok / warn / danger / info).
- **Thẻ bảng** bo `28px`, `overflow:hidden`:
  - **Toolbar** (`padding: 20px 24px 22px`, `flex-wrap: wrap`, `row-gap: 12px`): ô tìm kiếm (min 250px) · nhóm chip lọc (chip đang chọn nền `--sf-chip` chữ `--sf-accent`) · nút hành động chính bên phải (`flex:none`, `white-space:nowrap`, gradient teal, hover nâng 2px).
  - **Hàng tiêu đề** 11px uppercase `--sf-muted2`, dùng `grid-template-columns` riêng cho từng bảng.
  - **Hàng dữ liệu** bo `20px`, padding `15px 16px`, hover nền `--sf-hover`, `sfSlideLeft` stagger 55ms, click → toast "Đã mở chi tiết …" (trong codebase: mở trang/drawer chi tiết).
  - Ba loại ô: **plain** (chữ chính + phụ đề, tuỳ chọn font mono), **badge** (pill có dot, 5 tone), **progress** (nhãn + % + thanh tiến độ).
- Cột lưới từng bảng (giữ nguyên): Tài xế `1.5fr 1fr 1fr .9fr 1.1fr` · Tài khoản `1.3fr 1.4fr .9fr 1fr 1fr` · Phương tiện `1.1fr 1.2fr 1.2fr 1fr 1fr` · Chuyến `1.2fr 1.3fr 1.2fr 1.3fr 1fr` · Duyệt phiếu `1.1fr 1.2fr 1.3fr 1.2fr 1fr` · Cảnh báo `1.2fr 1.3fr 1.5fr 1fr 1fr` · Sự cố `1.1fr 1.2fr 1.5fr 1.1fr 1fr` · Thiết bị `1.1fr 1.3fr 1.1fr 1.2fr 1fr` · Bảo trì `1fr 1.1fr 1.4fr 1.1fr 1fr`.

### 12. Điều phối chuyến
`grid-template-columns: minmax(0,1fr) 360px`, `align-items:start`.
- Cột chính: **Thông tin chuyến** (lưới 2 cột: mã chuyến mono, segmented "Hàng hóa / Hành khách / Trung chuyển", điểm xuất phát, điểm đến, giờ khởi hành, giờ tới nơi) và **Phiếu xuất kho** (3 ô kho/công trình/người nhận; bảng dòng hàng 6 cột `1.6fr .8fr .8fr .8fr .8fr 40px` với Mặt hàng / Chứng từ / Thực xuất / Thực giao / Trả về (amber khi > 0) / nút xoá; nút "Thêm dòng hàng"; textarea ghi chú; nút "Lưu nháp" + "Phát hành & giao chuyến").
- Cột phải: **Đề xuất ghép cặp** (thẻ gradient teal: tên tài xế, biển số + model, điểm an toàn 92, giờ lái 2h40m, tải trọng; nút Áp dụng / Bỏ qua) và **Xem trước tuyến** (bản đồ nhỏ 150px với đường tuyến gradient + điểm đầu/cuối + quầng điểm ngập; số liệu quãng đường / thời gian / rủi ro tuyến; dải nhắc tuyến qua điểm ngập).

### 13. Điểm ngập & rủi ro
`grid-template-columns: minmax(0,1fr) 340px`.
- Trái: hàng chip lọc (Tất cả 12 / Ngập vừa 5 / Ngập nặng 4 / Đường bị chặn 3 / Chưa xác minh 4) + bản đồ cao 420px với 3 quầng ngập `sfBreathe`, ghim `water` / `block`, một ghim xe `sfDrift`.
- Phải: thẻ chi tiết điểm ngập — badge "NGẬP NẶNG", thời gian, tên "Nguyễn Trãi · Km 4", nguồn báo; lưới 4 tile (Mức ngập 45 cm, Độ tin cậy 86%, Báo cáo trùng 3, Xe bị ảnh hưởng 4 — tile amber); 3 nút dọc: Xác minh điểm ngập (gradient), Gửi cảnh báo cho 4 xe gần, Đánh dấu hết ngập.

### 14. Báo cáo
- 4 thẻ KPI (thẻ đầu gradient teal): Tổng cảnh báo 1.284 (−8%), Tổng chuyến 3.412 (+12%), Trung bình mỗi ngày 48,7, Cảnh báo phổ biến "Ngủ gật" (34%).
- Hai thẻ nửa chiều rộng: **Cảnh báo theo loại** (5 thanh ngang cao 10px: Ngủ gật 436/86%, Mất tập trung 312/62%, Dùng điện thoại 248/49% amber, Vượt tốc độ 190/38% amber, Gần điểm ngập 98/20% xanh; nút "Xuất CSV") và **Số chuyến theo ngày** (14 cột cao 210px, bo `12px 12px 5px 5px`, cột cao nhất gradient teal, `sfBar` stagger 40ms; trục ngày mono).

### 15. Cấu hình
Hai cột.
- Trái: **Giới hạn lái liên tục** (thanh trượt "Giới hạn tối đa 4h00m" 80% có núm 18px; 3 tile ngưỡng: Cấp 1 nhắc nghỉ 3h00m, Cấp 2 gần ngưỡng 3h40m amber, Khẩn dừng xe 4h00m đỏ) + **Bộ lọc cảnh báo AI** (4 switch: Ngủ gật, Mất tập trung, Dùng điện thoại, Vượt tốc độ; switch `46×26px`, núm `20px`, `left 3px → 23px`, transition `.32s cubic-bezier(.34,1.4,.64,1)`).
- Phải: **Kết nối hệ thống** (3 dòng trạng thái người-đọc-được: Máy chủ dữ liệu "Hoạt động bình thường", Dữ liệu vị trí xe "Đang nhận liên tục" có dot sống, Đồng bộ ứng dụng tài xế "20/20 thiết bị") + **Trợ lý điều hành** (switch bật/tắt, 2 dòng tuỳ chọn vận hành, nút "Chạy thử gợi ý" + "Lưu cấu hình"). Không hiển thị endpoint, API key hay tên model.

### 16. Hồ sơ cá nhân
Hai cột: thẻ hồ sơ (dải gradient 130px, avatar 76px bo `26px` viền trắng 5px chồng lên `-38px`, tên 21px, email, 2 chip vai trò/trạng thái, 3 dòng thông tin, dải ghi chú tự đăng xuất sau 8 giờ) và thẻ **Đổi mật khẩu** (3 ô mật khẩu, 4 vạch độ mạnh, nút cập nhật, dải cảnh báo thu hồi phiên cũ).

---

## Interactions & Behavior
- **Điều hướng**: click mục thanh bên → đổi `screen`; con trượt pill chạy tới nút mới (`.46s`), `<main>` chạy lại `sfRise`.
- **Thu gọn thanh bên**: chỉ bằng cách bấm **logo**; `width` transition `.42s`, nhãn nhóm và chữ mục ẩn, tooltip `title` giữ khả năng nhận biết.
- **Theme**: nút chân thanh bên đổi `data-sf-theme` trên phần tử shell giữa `light` / `dark`. Toàn bộ màu bề mặt/chữ lấy từ biến CSS; **panel kính trên bản đồ ghim mực tối** vì nền luôn trắng.
- **Bảng**: chip lọc lưu theo từng trang (`filterIdx[screen]`); click hàng → toast (thay bằng điều hướng thật).
- **Bản đồ**: pan/zoom như mô tả ở mục 3; chọn ghim mở báo cáo; ở chế độ compact, chọn ghim sẽ đóng panel danh sách; bật panel danh sách sẽ đóng báo cáo.
- **Tìm kiếm bản đồ**: khớp không phân biệt hoa thường trên biển số + tên tài xế + tuyến (xe) và tên + mức độ (điểm ngập), tối đa 6 kết quả, chọn kết quả sẽ xoá ô tìm và mở ghim tương ứng.
- **Form**: prototype không validate. Trong codebase cần: bắt buộc trường, kiểm tra mã chuyến trùng, giờ đến > giờ khởi hành, số lượng thực giao ≤ thực xuất, độ mạnh mật khẩu, xác nhận khớp.
- **Loading / error**: prototype không có. Cần skeleton cho bảng và bản đồ, trạng thái rỗng, lỗi tải, retry, và xử lý mất kết nối WebSocket.

## State Management
`screen` (trang hiện tại) · `collapsed` (thanh bên) · `theme` (`light`/`dark`) · `compact` (dẫn xuất từ `resize`) · `pillTop` (đo được, cho con trượt nav) · `filterIdx` (chip lọc theo trang) · `toast` (tự xoá 2400ms) · `zoom`, `panX`, `panY`, `dragging` (bản đồ) · `wallSel` (ghim đang chọn; `>= 100` nghĩa là điểm ngập, chỉ số `wallSel - 100`) · `selOpen` (panel báo cáo) · `vehicleList` (panel danh sách xe) · `wallQuery` (từ khoá tìm) · `goods` (dòng hàng phiếu xuất kho) · `ai` (4 công tắc bộ lọc) · `agent` (công tắc trợ lý) · `showPw`.

Dữ liệu cần fetch: danh sách xe + vị trí realtime, tài xế, tài khoản, chuyến, phiếu chứng từ, cảnh báo AI, sự cố/SOS, điểm ngập, thiết bị, phiếu bảo trì, số liệu báo cáo, cấu hình ngưỡng. Vị trí xe / cảnh báo / SOS nên đi qua WebSocket; phần còn lại REST + phân trang.

## Assets
- Không dùng ảnh bitmap. Toàn bộ icon là **Material Symbols Rounded** (webfont Google). Bản đồ giả được vẽ bằng CSS gradient + phần tử tuyệt đối — thay bằng maplibre-gl trong codebase.
- Font: Google Fonts (Plus Jakarta Sans, JetBrains Mono).

## Files
| File | Nội dung |
|---|---|
| `safefleet-command-web.html` | Bản mẫu **chạy độc lập** (mở bằng browser, không cần server) — dùng để xem và đo thiết kế |
| `source/SafeFleet Command Web.dc.html` | File thiết kế gốc: template + logic (dễ đọc hơn khi cần tra cứu markup/giá trị) |
| `source/support.js` | Runtime của môi trường prototype — **không dùng trong codebase thật** |

Codebase đích tham chiếu: `web_quan_ly/frontend` (`app/globals.css`, `DESIGN_SYSTEM.md`, `components/layout/Sidebar.tsx`, `data/mockData.ts`).
